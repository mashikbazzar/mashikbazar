# মাসিক বাজার (Monthly Bazar)

React + Vite + Supabase ভিত্তিক mobile-first website starter.

## Included
- বাংলা/ইংরেজি language switch
- Home, Shop, Packages, Cart, Checkout, Order Tracking, Login, My Orders, Admin
- Guest checkout; order stored in Supabase before WhatsApp opens
- Server-side product price calculation and unique order number
- Admin order status update, add basic products, drag-sort product order
- RLS policies, own-customer order access, admin-only product/order updates
- Starter categories, brands and 57 product names/units; no fabricated prices

## 1) Supabase setup
1. Create a project at https://supabase.com
2. Open SQL Editor and run all of `supabase/schema.sql`.
3. Run all of `supabase/seed.sql`.
4. Project Settings → API: copy Project URL and anon/publishable key.
5. Authentication → URL Configuration: add your deployed website URL.

## 2) Create first admin
1. Deploy/open site and use `/login` to sign up with your email.
2. Supabase → Authentication → Users: copy your user UUID.
3. Run this SQL, replacing UUID:
```sql
insert into public.admin_users(user_id) values ('YOUR-USER-UUID');
```
4. Log in and open `/admin`.

## 3) GitHub
1. Create a new repository named `monthly-bazar`.
2. Upload/extract all project files into repository root.
3. Copy `.env.example` to `.env` on your local machine and fill values.
4. Never commit `.env`; `.gitignore` excludes it.
5. GitHub Pages alone is not a database/backend. Use Cloudflare Pages or Netlify for hosting.

## 4) Local build
Requires Node.js 20+:
```bash
npm install
npm run dev
npm run build
```

## 5) Cloudflare Pages deployment
- Connect GitHub repository
- Build command: `npm run build`
- Output directory: `dist`
- Environment variables:
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`
  - `VITE_WHATSAPP_NUMBER` = `8801631421995`
- `public/_redirects` is included for SPA routes.

## Security notes
- Frontend may contain only Supabase anon/publishable key; RLS protects access.
- NEVER put Supabase `service_role` key in browser code, GitHub, or frontend environment variables.
- Review all RLS policies and test guest checkout, user isolation, admin access and order tracking before public launch.
- The order tracking RPC returns only order number/status/date after matching phone and order number. Apply rate limiting/CAPTCHA via edge/server middleware before wide public release.
- WhatsApp opens only after the order RPC confirms database insertion. If WhatsApp is cancelled, the order remains saved.

## Important scope note
This is a runnable starter implementation, not a fully finished production commerce platform. Admin CRUD for all category/brand/package fields, Google OAuth, delivery-area configuration, delivery fees, order cancellation/refund workflow, phone verification, abuse protection, image storage UI, audit logs, backups, and end-to-end tests still need implementation and testing. Admin currently supports order status updates, basic product creation and drag sorting. Do not announce the site publicly until the remaining production checklist is completed.
